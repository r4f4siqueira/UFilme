
function Filme(){
  return(
    <div>
      <h1>BEM VINDO A PAGINA DETALHES DO FILME</h1>
    </div>
  )
}

export default Filme;